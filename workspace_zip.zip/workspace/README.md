## Data Modeling ETL with PostgreSQL ##

### Introductio n###
 A startup called Sparkify wants to analyze the data they've been collecting on songs and user activity on their new music streaming app. The analytics team is particularly interested in understanding what songs users are listening to. Currently, they don't have an easy way to query their data, which resides in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app.

 In order to perform this I have created a database schema with fact and dimension tables and ETL pipeline that transfers data from files in two local directories into these tables in Postgres using Python and SQL

### Data Model ###

I have crated Star Schme Data model. Following are the tables and there data type.

#### Fact table ####
#####  Table: songplays #####

| Column  | Type |
| ------------- | ------------- |
| songplay_id  | int PRIMARY KEY |
| start_time  | date  |
| user_id  | int NOT NULL  |
| level  | text  |
| song_id | text |
| artist_id  | text  |
| session_id  | int  |
| location  | text   |
| user_agent  | text   |

#### Dimension table ####

##### Table: USERS #####

| Column  | Type |
| ------------- | ------------- |
| user_id  | int PRIMARY KEY |
| first_name  | text NOT NULL  |
| last_name  | text NOT NULL |
| gender  | text  |
| level | text |

##### Table: SONGS #####

| Column  | Type |
| ------------- | ------------- |
| song_id | text PRIMARY KEY |
| title  | text NOT NULL  |
| artist_id | text NOT NULL |
| year | int  |
| duration |float NOT NULL|


##### Table: ARTISTS #####

| Column  | Type |
| ------------- | ------------- |
| artist_id | text PRIMARY KEY |
| name  | text NOT NULL  |
| location | text |
| latitude | float  |
| longitude |float |


##### Table: TIME #####

| Column  | Type |
| ------------- | ------------- |
| start_time | date PRIMARY KEY |
| hour  | int  |
| day| int |
| week | int  |
| month |int |
| year |int |
| weekday |text |

### Building ETL Pipline ###

Create file ETL.Py

This file is divided into 4 function 

1. In Main() function I am estblishing connection with sparkifydb.
2. Once the connection is establishied I am listing "Song_data" and "Log_data" file from the data folder.
3. In process_song_file function i am reading song file and i am insering records in song and artist table.
4. In process_log_file function i am reading Log file, USERS and TIME table will be inserted from Log file. 
   From the ts column get time in year, day, hour, week, month and day of the week format. 
   Inorder to get song play deatils I am joining ARTISTS and song play detils based on the correspong song IDs,    these result will be inserted to song play details along with the song and user deatils.


## Running the files  ##

Follow the steps to extract and load the data into the data model.


1. Run create_tables.py to create/reset the tables by
	python create_tables.py
    This step will create all the required tables
2. Run ETL process and load data into database by
	python etl.py
    on running this file data in the file will be loaded table.
3. Check whether the data has been loaded into database by executing queries test.ipynb


## Files Strcture: ##

data folder: where all song and log data JSONS file is present
sql_queries.py	: Contains the SQL queries for data modeling and ETL
create_tables.py:	Drops and creates tables. (Reset the tables)
test.ipynb	 Exploring the database tables
etl.ipynb:Processes a file from song_data and log_data and loads the data into tables in single steps
etl.py	:Processes all files from song_data and log_data and loads them into tables
README	:Readme file

Sample Queryes for Data analysis:

SELECT count(*),level FROM users group by level ---This result will give number user using paid and Free version.

sql select A.artist_id,A.name,max(B.duration) from artists A join songs B on A.artist_id=B.artist_id
group by A.artist_id,A.name--This will give Maximu



